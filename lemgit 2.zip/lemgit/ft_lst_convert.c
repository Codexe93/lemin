/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lst_convert.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/07 19:14:31 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:17:09 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

static t_way	*ft_nway(char *room)
{
	t_way		*fresh;

	if ((fresh = (t_way*)ft_memalloc(sizeof(t_way))) == NULL)
		return (NULL);
	if ((fresh->room = ft_strdup(room)) == NULL)
		return (NULL);
	fresh->ant = 0;
	if ((fresh->next = (t_way**)ft_memalloc(sizeof(t_way*))) == NULL)
		return (NULL);
	fresh->next[0] = NULL;
	return (fresh);
}

static t_way	*ft_lst_newstart(char *room, int sw)
{
	t_way		*fresh;
	int			i;

	i = -1;
	if ((fresh = (t_way*)ft_memalloc(sizeof(t_way))) == NULL)
		return (NULL);
	if ((fresh->room = ft_strdup(room)) == NULL)
		return (NULL);
	fresh->ant = 0;
	if ((fresh->next = (t_way**)ft_memalloc(sizeof(t_way*) * (sw + 1))) == NULL)
		return (NULL);
	while (++i < sw)
		fresh->next[i] = NULL;
	return (fresh);
}

static int		ft_manage_end(t_way *way, short **done, int sw, t_info *info)
{
	if (!(ft_nb_ant_max(way, done, sw)))
		return (0);
	if (!(ft_print_manager(way, info, sw)))
		return (0);
	ft_free_param(sw, way);
	return (1);
}

int				ft_lstadd_ways(short **done, t_info *info, int sw, t_way *way)
{
	short		value;
	t_way		*save;
	int			i;
	int			k;

	k = -1;
	if (!(way = ft_lst_newstart(info->room[0].name, sw)))
		return (0);
	way->ant = info->nb_ants;
	while (++k < sw)
	{
		save = way;
		value = 1;
		while (++value <= done[k][1])
		{
			i = 0;
			while (i < info->nb_room && done[k][i] != value)
				i++;
			if (!(save->next[value == 2 ? k : 0] = ft_nway(info->room[i].name)))
				return (0);
			save = save->next[value == 2 ? k : 0];
		}
	}
	return (ft_manage_end(way, done, sw, info));
}
