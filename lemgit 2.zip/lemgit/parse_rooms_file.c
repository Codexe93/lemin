/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_room_file.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/07 17:11:51 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/15 04:22:34 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

static int		check_for_attr(t_info *infos, int type)
{
	int			i;

	i = -1;
	if (type == 1)
	{
		if (infos->room[0].name)
			return (-1);
	}
	else if (type == 2)
	{
		if (infos->room[1].name)
			return (-1);
	}
	return (type);
}

static int		handle_comment(char *line, t_info *infos, int next_attr)
{
	if (ft_strcmp(line, "##start") == 0)
		return (next_attr == 0 ? check_for_attr(infos, 1) : -1);
	else if (ft_strcmp(line, "##end") == 0)
		return (next_attr == 0 ? check_for_attr(infos, 2) : -1);
	return (next_attr);
}

static int		check_name(char *name, t_info *infos)
{
	int			i;

	i = -1;
	while (++i < infos->nb_room)
	{
		if (infos->room[i].name == NULL)
			continue ;
		if (ft_strcmp(name, infos->room[i].name) == 0)
			return (-1);
	}
	return (0);
}

static int		add_room(char *line, int type, t_info *infos, int i)
{
	char		**split_tab;

	if ((split_tab = ft_strsplit(line, ' ')) == NULL)
		exception_display(1);
	if (!split_tab || !split_tab[0] || check_name(split_tab[0], infos) == -1)
	{
		ft_deltab(&split_tab);
		return (error_display(-1, -1));
	}
	if (type != 0)
		i = type == 1 ? 0 : 1;
	if ((infos->room[i].name = ft_strdup(split_tab[0])) == NULL)
	{
		ft_deltab(&split_tab);
		exception_display(1);
	}
	infos->room[i].x = ft_atoi(split_tab[1]);
	infos->room[i].y = ft_atoi(split_tab[2]);
	infos->room[i].attribute = type;
	ft_deltab(&split_tab);
	return (0);
}

int				parse_file(char **file, t_info *infos, int i, int room_nb)
{
	char		**file_tab;
	int			next_attr;

	if ((file_tab = ft_strsplit(*file, '\n')) == NULL)
		exception_display(1);
	if ((infos->room = (t_room*)ft_memalloc(sizeof(t_room)
					* infos->nb_room)) == NULL)
		exception_display(1);
	next_attr = 0;
	if (check_start_end(file_tab) == -1)
		return (free_and_return_err(NULL, NULL, file_tab));
	while (file_tab[++i] && next_attr != -1)
	{
		if (*(file_tab[i]) == '#')
			next_attr = handle_comment(file_tab[i], infos, next_attr);
		else if (add_room(file_tab[i], next_attr, infos, room_nb) == -1)
			return (clean_exit(&file_tab));
		else if (next_attr == 0)
			room_nb++;
		if (next_attr > 0 && *(file_tab[i]) != '#')
			next_attr = 0;
	}
	ft_deltab(&file_tab);
	return (next_attr == 0 ? 0 : special_error(file));
}
