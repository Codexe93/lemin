/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_rooms.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 19:18:14 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/15 01:44:37 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "./libft/libft.h"

static int			is_line_valid(char *line, t_info *infos)
{
	int				i;
	int				count;
	int				nb_word;

	i = -1;
	count = 0;
	if (*line == '#')
		return (0);
	if ((nb_word = word_count(line, ' ')) < 3)
		return (-1);
	else if (nb_word > 3)
		return (-1);
	if (ft_isalnum(line[0]) == 0)
		return (error_display(1, -1));
	while (line[++i])
	{
		if (ft_isprint(line[i]) == 0)
			return (error_display(-1, -1));
		if (line[i] == ' ')
			count++;
	}
	infos->nb_room++;
	if (count != 2 && nb_word == 3)
		return (-1);
	return (0);
}

static void			concat_buff(t_info *infos, char **log, char **line)
{
	if (ft_strlen(*line) > BUFFS - 1)
	{
		ft_strdel(line);
		exception_display(2);
	}
	if (infos->cat + ft_strlen(*line) > BUFFS)
	{
		if (!(*log = ft_strjoinf(*log, infos->buffer)))
		{
			ft_strdel(line);
			exception_display(1);
		}
		ft_bzero(infos->buffer, BUFFS + 4);
		infos->cat = 0;
	}
	ft_stradd(&(infos->buffer[0]), *line, infos->cat);
	infos->cat = ft_strlen(infos->buffer);
}

char				*parse_rooms(t_info *infos, char **log)
{
	int				ret;
	char			*line;

	infos->nb_room = 0;
	while ((ret = get_next_line(0, &line)) > 0)
	{
		if ((*(line) != '#') && ft_strchr(line, '-'))
			break ;
		if (is_line_valid(line, infos) == -1 || (*(line)) == 'L')
			return (free_and_return_err(line, *log, NULL) == -1 ? NULL : NULL);
		concat_buff(infos, log, &line);
		if (!(*log))
			exception_display(1);
		ft_strdel(&line);
	}
	if (infos->buffer[0] != '\0')
		if (!(*log = ft_strjoinf(*log, infos->buffer)))
			exception_display(1);
	infos->cat = 0;
	ft_bzero(infos->buffer, BUFFS + 4);
	if (ret != 1)
		return (ft_gnl_error(ret));
	if (parse_file(log, infos, -1, 2) == -1)
		ft_strdel(&line);
	return (line);
}
