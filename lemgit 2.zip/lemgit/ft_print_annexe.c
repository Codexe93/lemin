/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_annexe.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/12 18:19:45 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:19:08 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/ft_printf/ft_printf.h"

static void		ft_print_next(t_info info, int nbr, char *name, int a)
{
	if (info.flag_e && a == 2)
	{
		ft_printf("\033[35;08mL%d-%s\033[00m ", nbr, name);
		return ;
	}
	if (info.flag_s && a == 1)
	{
		ft_printf("\033[36;01mL%d-%s\033[00m ", nbr, name);
		return ;
	}
	ft_printf("L%d-%s ", nbr, name);
}

void			ft_print_ants(t_info info, int nbr, char *name, int a)
{
	ft_print_next(info, nbr, name, a);
}
