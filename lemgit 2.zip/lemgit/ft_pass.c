/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_pass.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/11 17:46:08 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:18:24 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"

int		ft_can_pass(t_big big)
{
	int k;

	if (big.current == 0)
		return (1);
	k = -1;
	while (++k < big.size)
		if (big.tmp_mat[big.current][k] == -1)
			return (1);
	k = -1;
	while (++k < big.size)
	{
		if (big.mat[big.current][k] > 2)
			return (0);
	}
	return (1);
}

int		can_add(t_big *big, int i)
{
	int k;
	int	count;

	k = -1;
	count = 0;
	if (big->tmp_mat[big->current][i] == 1 && !big->mark[i]
			&& ft_can_pass(*big))
		return (1);
	else if (big->tmp_mat[big->current][i] > 2 && !big->mark[i]
			&& big->current != 0 && big->current != 1)
	{
		while (++k < big->size)
		{
			if (big->tmp_mat[big->current][k]
					> big->tmp_mat[big->current][i])
				return (0);
		}
		return (2);
	}
	return (0);
}

int		ft_find_first_ney(t_big big, t_info info)
{
	int i;

	i = -1;
	while (++i < info.nb_room)
	{
		if (big.mat[0][i] == 1)
			return (1);
	}
	return (0);
}

int		ft_find_ney(t_big *big, t_file **file, int *i)
{
	int		choice;

	choice = can_add(big, *i);
	if (!choice)
		return (1);
	if (*i != 1)
	{
		if (!(ft_add_param(file, *i)))
			return (0);
		big->mark[*i] = big->count_mark;
	}
	if (choice == 1)
	{
		big->tmp_mat[big->current][*i] = 2;
		big->tmp_mat[*i][big->current] = 2;
	}
	else if (choice == 2)
	{
		big->tmp_mat[big->current][*i] = -1;
		big->tmp_mat[*i][big->current] = -1;
		*i = big->size;
	}
	if (*i == 1)
		return (0);
	return (1);
}

int		ft_update_mat(t_file *file, t_big *big, t_info *info, t_save **save)
{
	if (!file)
	{
		if (!(ft_update(big, info, save)))
			return (0);
	}
	return (1);
}
