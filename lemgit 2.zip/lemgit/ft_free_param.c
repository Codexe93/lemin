/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_free_param.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/11 09:35:32 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:18:01 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

static void		ft_chain_del(t_way *way)
{
	if (!way)
		return ;
	if (way->next[0])
		ft_chain_del(way->next[0]);
	ft_strdel(&(way)->room);
	free(way->next);
	way->next = NULL;
	free(way);
	way = NULL;
}

void			ft_free_param(int sw, t_way *way)
{
	int		i;

	i = -1;
	if (!way)
		return ;
	while (++i < sw)
		ft_chain_del(way->next[i]);
	ft_strdel(&(way)->room);
	free(way->next);
	way->next = NULL;
	free(way);
	way = NULL;
}

void			ft_free_big(t_big *big)
{
	int			size;
	int			i;

	size = big->size;
	i = -1;
	while (++i < size)
		free(big->tmp_mat[i]);
	free(big->tmp_mat);
	big->tmp_mat = NULL;
	free(big->mark);
	big->mark = NULL;
}

void			ft_free_save(t_save **save)
{
	int			i;
	int			debit;

	i = -1;
	if (!*save)
		return ;
	if ((*save)->next)
		ft_free_save(&((*save)->next));
	debit = (*save)->debit;
	while (++i < debit)
		free((*save)->tab[i]);
	free((*save)->tab);
	(*save)->tab = NULL;
	free((*save)->next);
	(*save)->next = NULL;
	free(*save);
	*save = NULL;
}
