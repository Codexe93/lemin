/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parcours.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/11 15:56:22 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:17:53 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

static t_file		*creat_file_n_mark(short id, t_big *big, t_info info)
{
	t_file		*fresh;
	int			i;

	i = -1;
	if ((fresh = (t_file*)ft_memalloc(sizeof(t_file))) == NULL)
		return (NULL);
	fresh->id = id;
	fresh->next = NULL;
	while (++i < info.nb_room)
		big->mark[i] = 0;
	big->mark[0] = 1;
	big->count_mark = 0;
	big->end = 0;
	return (fresh);
}

static int			ft_init_big(t_big *big, t_info info)
{
	int				i;
	int				j;

	i = -1;
	big->mat = info.links;
	if (!(big->tmp_mat = (short**)malloc(sizeof(short*) * info.nb_room)))
		return (0);
	while (++i < info.nb_room)
	{
		if (!(big->tmp_mat[i] = (short*)malloc(sizeof(short) * info.nb_room)))
			return (0);
		j = -1;
		while (++j < info.nb_room)
			big->tmp_mat[i][j] = big->mat[i][j];
	}
	if (!(big->mark = (short*)malloc(sizeof(short) * info.nb_room)))
		return (0);
	big->current = 0;
	big->size = info.nb_room;
	return (1);
}

static void			ft_end_case(int i, t_file **file, t_big *big)
{
	if (i == 1)
		ft_del_all_param(file);
	if (*file)
		big->current = (*file)->id;
}

short				**ft_manage_list(t_info *info, t_big *big, t_save **save)
{
	t_file			*file;
	int				i;

	if (!(ft_init_big(big, *info)))
		return (NULL);
	while (ft_find_first_ney(*big, *info))
	{
		if ((file = creat_file_n_mark(0, big, *info)) == NULL)
			return (NULL);
		while (file)
		{
			ft_del_first_param(&file);
			i = -1;
			big->count_mark++;
			while (++i < info->nb_room)
				if (!ft_find_ney(big, &file, &i) && (big->end = 1))
					break ;
			ft_end_case(i, &file, big);
		}
		if (!big->end)
			break ;
		if (!(ft_update_mat(file, big, info, save)))
			return (NULL);
	}
	return (ft_choose_mat(*save, info, *big));
}
