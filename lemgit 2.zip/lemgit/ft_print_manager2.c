/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/14 04:35:47 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:19:28 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem-in.h"
#include <stdlib.h>

int				ft_print_manager(t_way *way, t_info *info, int sw)
{
	int			*tab;

	if ((tab = ft_creat_tab(way, sw)) == NULL)
		return (0);
	ft_print_manager2(sw, info, way, tab);
	free(tab);
	return (1);
}
