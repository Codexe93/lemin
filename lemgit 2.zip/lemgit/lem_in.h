/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lem_in.h                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: roliveir <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/07 18:11:51 by roliveir          #+#    #+#             */
/*   Updated: 2018/12/15 05:41:51 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef LEM_IN_H
# define LEM_IN_H

# define BUFFS 4096

typedef	struct		s_way
{
	char			*room;
	int				ant;
	int				max;
	struct s_way	**next;
}					t_way;

typedef struct		s_room
{
	char			*name;
	int				id;
	int				x;
	int				y;
	int				attribute;
}					t_room;

typedef struct		s_big
{
	short			**mat;
	short			**tmp_mat;
	int				mod;
	short			*mark;
	short			current;
	short			size;
	int				count_mark;
	int				end;
	int				score;
}					t_big;

typedef struct		s_file
{
	short			id;
	struct s_file	*next;
}					t_file;

typedef struct		s_save
{
	short			**tab;
	int				score;
	int				debit;
	struct s_save	*next;
}					t_save;

typedef struct		s_info
{
	char			buffer[BUFFS + 4];
	int				cat;
	int				nb_ants;
	int				nb_left;
	int				nb_room;
	int				t;
	short			**links;
	t_room			*room;
	int				flag_l;
	int				flag_d;
	int				flag_s;
	int				flag_e;
	int				nb_l;
	int				debit;
}					t_info;

typedef struct		s_score
{
	int				*tab;
	int				*tab_max;
	int				len;
}					t_score;

int					parse(t_info *infos);
char				*parse_rooms(t_info *infos, char **log);
int					parse_file(char **file, t_info *infos, int i, int room_nb);
int					word_count(const char *s, char c);
int					clean_rooms(t_info *infos);
int					check_start_end(char **tab);
void				ft_check_it(t_info *data, int ret, char **line, char **log);
int					ft_check_links(t_info *data, char **log);
void				ft_parse_tubes(char *line, t_info *data, int i,
		char **log);
int					ft_is_int_tab(char *line, t_info *data, int *i);
char				*ft_stradd(char *dest, const char *src, int start);
void				ft_cat_buff(t_info *info, char **log);

void				exception_display(int err);
int					error_display(int err, int ret);
char				*ft_gnl_error(int ret);
void				ft_exception_tube_1(char **line, t_info *data, int id,
		char **log);
void				ft_exception_tube_2(t_info *data, char **log);
void				ft_check_it(t_info *data, int ret, char **line, char **log);
int					ft_check_links(t_info *data, char **log);
int					ft_warning_tube_1(char **line);
int					ft_warning_tube_2(char **line);
int					ft_warning_tube_3(char **line);
int					ft_warning_tube_4(void);
int					free_and_return_err(char *line, char *line2, char **tab);
void				ft_free_data(t_info *data);
void				ft_free_links(t_info *data);
int					ft_quit_free(char *line);
int					ft_return_n_free(char **line, char **log, int id,
		t_info *info);
void				ft_free_param(int sw, t_way *way);
void				ft_free_save(t_save **save);
void				ft_free_big(t_big *big);
int					ft_lstadd_ways(short **done, t_info *infos, int sw,
		t_way *way);
int					ft_print_manager(t_way *way, t_info *info, int sw);
int					ft_nb_ant_max(t_way *way, short **done, int sw);
void				ft_print_ants(t_info info, int nbr, char *name, int a);
void				ft_print_manager2(int sw, t_info *info, t_way *way,
		int *tab);
void				ft_mv_next(t_big *big, int curr, int k, int *index);
void				ft_mv_tmp(t_big *big, int *line, int *k, t_info info);
void				ft_del_all_param(t_file **file);
void				ft_del_first_param(t_file **file);
int					ft_add_param(t_file **file, short id);
int					ft_find_first_ney(t_big big, t_info info);
short				**ft_convert_mat(t_info *info, t_big big);
int					ft_update_mat(t_file *file, t_big *big, t_info *info,
		t_save **save);
short				**ft_manage_list(t_info *info, t_big *big, t_save **save);
int					ft_update(t_big *big, t_info *info, t_save **save);
int					ft_find_ney(t_big *big, t_file **file, int *i);
int					ft_save_manager(t_save **save, t_big *big, t_info *info);
short				**ft_choose_mat(t_save *save, t_info *info, t_big big);
int					*new_tab(short **done, int sw);
int					gmax(int *s_len, int k, short **done, int i);
int					ft_calc_score(short **mat, t_big *big, int nb_ants,
		int debit);
int					clean_exit(char ***t);
int					special_error(char **t);

#endif
