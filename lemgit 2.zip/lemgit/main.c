/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/07 16:58:34 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 06:17:06 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"
#include "libft/ft_printf/ft_printf.h"
#include <unistd.h>

static void		ft_free_info(t_info *infos, t_save **save, t_big *big)
{
	ft_free_data(infos);
	ft_free_links(infos);
	if (save)
		ft_free_save(save);
	ft_free_big(big);
}

static void		ft_init_flag(t_info *info, t_way *way, int id)
{
	if (id == 404)
	{
		ft_printf("\033[36moptions\033[0m:\n");
		ft_printf("\t-l : show \033[1ml\033[0mines\n");
		ft_printf("\t-s : show \033[1ms\033[0mtarting rooms\n");
		ft_printf("\t-e : show \033[1me\033[0mnding rooms\n");
		ft_printf("\t-d : \033[1md\033[0misable logs\n");
		exit(0);
	}
	info->flag_l = 0;
	info->flag_d = 0;
	info->flag_s = 0;
	info->flag_e = 0;
	info->nb_l = 1;
	way->ant = info->nb_ants;
	info->nb_left = info->nb_ants;
	info->cat = 0;
	info->debit = 0;
}

void			option(int argc, char **argv, t_info *info, t_way *way)
{
	int			i;

	i = 0;
	if (way)
		ft_init_flag(info, way, 0);
	if (!way)
		info->flag_d = 0;
	while (++i < argc && argv[i])
	{
		if (argv[i][0] == '-')
		{
			if (!ft_strcmp(argv[i], "-l"))
				info->flag_l = 1;
			if (!ft_strcmp(argv[i], "-s"))
				info->flag_s = 1;
			if (!ft_strcmp(argv[i], "-e"))
				info->flag_e = 1;
			if (!ft_strcmp(argv[i], "-d"))
				info->flag_d = 1;
			if (!ft_strcmp(argv[i], "-h"))
				ft_init_flag(NULL, NULL, 404);
		}
	}
}

static int		ft_no_way(t_big *big, t_save **save, t_info *info)
{
	ft_putstr("\033[31mERROR\033[0m : Cannot find any way\n");
	ft_free_info(info, save, big);
	return (1);
}

int				main(int argc, char **argv)
{
	t_info		info;
	short		**mat;
	t_way		way;
	t_big		big;
	t_save		*save;

	save = NULL;
	if (read(0, info.buffer, 0) < 0)
		return (1);
	ft_bzero(info.buffer, BUFFS + 4);
	info.cat = 0;
	option(argc, argv, &info, NULL);
	if (parse(&info) == -1)
		return (0);
	option(argc, argv, &info, &way);
	if ((mat = ft_manage_list(&info, &big, &save)) == NULL || !info.debit)
		return (ft_no_way(&big, &save, &info));
	if (!(ft_lstadd_ways(mat, &info, info.debit, &way)))
		exit(1);
	ft_putchar('\n');
	ft_free_info(&info, &save, &big);
	return (0);
}
