/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calc_score.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/14 04:52:04 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:06:01 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include <stdlib.h>

static int		*swap_tab(int *tab_max, int debit)
{
	int			i;
	int			tmp;

	i = -1;
	while (++i < debit - 1)
	{
		if (tab_max[i] < tab_max[i + 1])
		{
			tmp = tab_max[i];
			tab_max[i] = tab_max[i + 1];
			tab_max[i + 1] = tmp;
			i = -1;
		}
	}
	return (tab_max);
}

static void		ft_find_score(t_big *big, int nb_ants, int debit, int *tab_max)
{
	int			i;
	int			tmp;

	i = 0;
	tmp = debit;
	while (i < tmp && nb_ants > 0)
	{
		while (tab_max[i] < nb_ants)
		{
			big->score++;
			nb_ants = nb_ants - debit;
		}
		debit--;
		i++;
	}
}

int				ft_calc_score(short **mat, t_big *big, int nb_ants, int debit)
{
	int			i;
	int			k;
	int			tmp;
	t_score		score;

	score.len = 0;
	if (!(score.tab = new_tab(mat, debit)))
		return (0);
	big->score = big->score * 0 + score.tab[0];
	if (!(score.tab_max = (int*)malloc(sizeof(int) * debit)))
		return (0);
	tmp = -1;
	k = 0;
	while (++tmp < debit && (i = -1))
		while (++i < debit)
			if (score.tab[k] == mat[i][1] - 1)
			{
				score.tab_max[i] = gmax(&(score.len), k, mat, i);
				k++;
			}
	score.tab_max = swap_tab(score.tab_max, debit);
	ft_find_score(big, nb_ants, debit, score.tab_max);
	free(score.tab);
	free(score.tab_max);
	return (1);
}
