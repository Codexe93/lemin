/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/08 02:52:57 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:52:55 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"
#include "libft/ft_printf/ft_printf.h"

static void		ft_print_recursive(t_way *way, t_info *info, char *r)
{
	if (way->next[0] == NULL || way->next[0]->next[0] == NULL)
	{
		if (way->ant > 0 && ft_strcmp(r, info->room[0].name))
		{
			ft_print_ants(*info, way->ant, info->room[1].name, 2);
			way->ant = 0;
			info->nb_left--;
		}
		else if (way->ant > 0 && !ft_strcmp(r, info->room[0].name))
			info->nb_left--;
		return ;
	}
	ft_print_recursive(way->next[0], info, way->room);
	if (way->ant > 0)
	{
		ft_print_ants(*info, way->ant, way->next[0]->room, 0);
		way->next[0]->ant = way->ant;
		way->ant = 0;
	}
}

static void		ft_handler(t_way *way, t_info *info, int *count, int i)
{
	if (way->ant > way->next[i]->max)
	{
		if (*count == 1 && info->flag_l)
			ft_printf("\033[32;01m%d\033[00m ", info->nb_l);
		ft_print_ants(*info, *count, way->next[i]->room, 1);
		way->next[i]->ant = *count;
		(*count)++;
		way->ant--;
	}
}

static void		ft_print_last_line(t_info *info)
{
	if (info->nb_left > 0)
	{
		info->nb_l++;
		ft_putchar('\n');
		if (info->nb_left && info->flag_l)
			ft_printf("\033[32;01m%d\033[00m ", info->nb_l);
	}
}

void			ft_print_manager2(int sw, t_info *info, t_way *way, int *tab)
{
	int			i;
	int			k;
	int			count;

	count = 1;
	while (info->nb_left > 0)
	{
		k = 0;
		i = 0;
		while (k < sw)
		{
			if (tab[k] == way->next[i]->max)
			{
				ft_print_recursive(way->next[i], info, way->room);
				ft_handler(way, info, &count, i);
				k++;
				i++;
			}
			else
				i++;
			if (i == sw)
				i = 0;
		}
		ft_print_last_line(info);
	}
}
