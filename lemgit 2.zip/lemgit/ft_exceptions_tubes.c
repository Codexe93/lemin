/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_exceptions_tubes.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 21:00:00 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/14 22:04:39 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"
#include "libft/ft_printf/ft_printf.h"

void		ft_free_data(t_info *data)
{
	int		i;

	i = 0;
	if (!data->room)
		return ;
	while (i < data->nb_room)
	{
		if (data->room[i].name)
			ft_strdel(&(data->room[i].name));
		i++;
	}
	free(data->room);
}

void		ft_free_links(t_info *data)
{
	int		i;

	i = 0;
	if (!data->links)
		return ;
	while (data->links[i])
	{
		free(data->links[i]);
		i++;
	}
	free(data->links);
}

void		ft_exception_tube_1(char **line, t_info *data, int id, char **log)
{
	if (id != 2)
		ft_strdel(line);
	ft_strdel(log);
	ft_free_data(data);
	if (id > 0)
		ft_free_links(data);
	ft_printf("\x1B[35mEXCEPTION\x1B[0m : Malloc break exception.\n");
	if (id != 2)
		exit(1);
}

void		ft_exception_tube_2(t_info *data, char **log)
{
	ft_free_data(data);
	ft_free_links(data);
	ft_strdel(log);
	ft_printf("\x1B[35mEXCEPTION\x1B[0m : get_next_line() exception.\n");
	exit(1);
}

void		ft_check_it(t_info *data, int ret, char **line, char **log)
{
	if (line)
		if (ft_strchr(*line, 127))
		{
			ft_printf("\x1B[35mEXCEPTION\x1B[0m : You used /dev/random.\n");
			ft_free_data(data);
			ft_free_links(data);
			ft_strdel(line);
			exit(1);
		}
	if (ret == 0)
	{
		if (!(ft_check_links(data, log)))
		{
			ft_free_data(data);
			ft_free_links(data);
			ft_printf("\x1B[31mERROR\x1B[0m : No tube given, aborting.\n");
			exit(1);
		}
	}
}
