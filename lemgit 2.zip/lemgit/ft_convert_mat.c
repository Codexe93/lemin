/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_convert_mat.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/11 22:32:05 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:07:10 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include <stdlib.h>

short	*ft_init_line(short *line, int size)
{
	int k;

	k = 1;
	while (k < size)
	{
		line[k] = 0;
		k++;
	}
	line[0] = 1;
	return (line);
}

void	ft_go_to_next(int *room, int *k, int *prev, t_info info)
{
	*prev = *room;
	*room = *k;
	*k = info.nb_room + 2;
}

short	*ft_newline(t_big big, int room, t_info info)
{
	short	*line;
	int		k;
	int		prev;
	int		index;

	index = 2;
	prev = 0;
	if ((line = (short*)malloc(sizeof(short) * info.nb_room)) == NULL)
		return (NULL);
	line = ft_init_line(line, info.nb_room);
	line[room] = 2;
	while (room != 1 && (k = 0) == 0)
	{
		while (++k < info.nb_room)
			if (big.mat[room][k] > 1 && k != prev)
				ft_go_to_next(&room, &k, &prev, info);
		index++;
		line[room] = index;
		if (k == info.nb_room)
		{
			free(line);
			return (NULL);
		}
	}
	return (line);
}

short	**ft_convert_mat(t_info *info, t_big big)
{
	short	**mat;
	int		k;
	int		c;

	k = -1;
	info->debit = 0;
	while (++k < info->nb_room)
	{
		if (big.mat[0][k] > 1)
			info->debit++;
	}
	if ((mat = (short**)malloc(sizeof(short*) * info->debit)) == NULL)
		return (NULL);
	k = -1;
	c = -1;
	while (++k < info->nb_room)
		if (big.mat[k][0] > 2)
			if ((mat[++c] = ft_newline(big, k, *info)) == NULL)
				c--;
	info->debit = c + 1;
	return (mat);
}
