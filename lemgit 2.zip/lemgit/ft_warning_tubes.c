/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_warning_tubes.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 20:02:45 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/14 22:06:29 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft/libft.h"
#include "libft/ft_printf/ft_printf.h"

int		ft_warning_tube_1(char **line)
{
	ft_strdel(line);
	ft_printf("\x1B[33mWARNING\x1B[0m : Room doesn't exist, tube ignored.\n");
	return (1);
}

int		ft_warning_tube_2(char **line)
{
	ft_strdel(line);
	ft_printf("\x1B[33mWARNING\x1B[0m : Room name can't be empty.\n");
	return (1);
}

int		ft_warning_tube_3(char **line)
{
	ft_strdel(line);
	ft_printf("\x1B[33mWARNING\x1B[0m : Too many separators.\n");
	return (1);
}

int		ft_warning_tube_4(void)
{
	ft_printf("\x1B[36mNOTE\x1B[0m : Tube already exists.\n");
	return (0);
}

int		ft_quit_free(char *line)
{
	ft_strdel(&line);
	exit(1);
	return (0);
}
