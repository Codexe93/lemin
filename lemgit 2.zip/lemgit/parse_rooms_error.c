/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_rooms_error.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/06 10:48:18 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/15 04:22:14 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "./libft/ft_printf/ft_printf.h"
#include "libft/libft.h"

char			*ft_gnl_error(int ret)
{
	if (ret == -1)
		exception_display(-1);
	else if (ret == 0)
		error_display(-1, -1);
	return (NULL);
}

void			exception_display(int err)
{
	if (err == -1)
		ft_printf("\033[35mEXCEPTION: \033[0mGNL Failed /!\\ Exiting...\n");
	else if (err == 1)
		ft_printf("\033[35mEXCEPTION: \033[0mMalloc Failed /!\\ Exiting...\n");
	else
		ft_printf("\033[31mERROR: \033[0mEnd or Start are following.\n");
	exit(EXIT_FAILURE);
}

int				error_display(int err, int ret)
{
	ft_printf("\033[31mERROR:\033[0m Room parsing failed.\n");
	ret = err;
	return (-1);
}

int				special_error(char **t)
{
	ft_strdel(t);
	error_display(-1, -1);
	exit(1);
}

int				clean_exit(char ***t)
{
	ft_deltab(t);
	return (-1);
}
