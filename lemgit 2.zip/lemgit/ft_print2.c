/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print2.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/14 04:35:47 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:18:48 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include <stdlib.h>

static int	*ft_creat_tab(t_way *way, int sw)
{
	int		*tab;
	int		i;
	int		tmp;

	i = -1;
	if ((tab = (int*)malloc(sizeof(int) * sw)) == NULL)
		return (0);
	while (++i < sw)
		tab[i] = way->next[i]->max;
	i = -1;
	while (++i + 1 < sw)
	{
		if (tab[i] < tab[i + 1])
		{
			tmp = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = tmp;
			i = -1;
		}
	}
	return (tab);
}

int			ft_print_manager(t_way *way, t_info *info, int sw)
{
	int		*tab;

	if ((tab = ft_creat_tab(way, sw)) == NULL)
		return (0);
	ft_print_manager2(sw, info, way, tab);
	free(tab);
	return (1);
}
