/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stradd.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/13 17:13:03 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/13 17:14:18 by mmervoye         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

char	*ft_stradd(char *dest, const char *src, int start)
{
	size_t	i;
	size_t	j;

	i = 0;
	j = start;
	while (src[i] != '\0')
	{
		dest[j] = src[i];
		i++;
		j++;
	}
	dest[j] = '\n';
	dest[j + 1] = '\0';
	return (dest);
}
