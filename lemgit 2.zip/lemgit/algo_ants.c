/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   algo_ants.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/10 10:28:05 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 06:14:06 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include <stdlib.h>

int			gmax(int *s_len, int k, short **done, int i)
{
	int		f;

	if (k == 0)
	{
		*s_len = *s_len + done[i][1] - 1;
		return (0);
	}
	f = (*s_len + done[i][1] - 1) * k - (*s_len) * (k + 1);
	*s_len = *s_len + done[i][1] - 1;
	return (f);
}

int			*new_tab(short **done, int sw)
{
	int		*tab;
	int		i;
	int		tmp;

	i = -1;
	if ((tab = (int*)malloc(sizeof(int) * sw)) == NULL)
		return (NULL);
	while (++i < sw)
		tab[i] = done[i][1] - 1;
	i = -1;
	while (++i + 1 < sw)
	{
		if (tab[i] > tab[i + 1])
		{
			tmp = tab[i];
			tab[i] = tab[i + 1];
			tab[i + 1] = tmp;
			i = -1;
		}
	}
	return (tab);
}

static int	ft_same(int k, int *tab)
{
	if (k > 0)
	{
		if (tab[k] == tab[k - 1] && tab[k] == tab[0])
			return (0);
	}
	return (k);
}

int			ft_nb_ant_max(t_way *way, short **done, int sw)
{
	int		i;
	int		k;
	int		tmp;
	int		s_len;
	int		*tab;

	s_len = 0;
	if (!(tab = new_tab(done, sw)))
		return (0);
	tmp = -1;
	k = 0;
	while (++tmp < sw)
	{
		i = -1;
		while (++i < sw)
			if (tab[k] == done[i][1] - 1)
			{
				way->next[i]->max = gmax(&s_len, ft_same(k, tab), done, i);
				k++;
			}
	}
	free(tab);
	return (1);
}
