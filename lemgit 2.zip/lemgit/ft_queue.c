/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_queue.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/12 15:06:16 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:19:54 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

void		ft_del_first_param(t_file **file)
{
	t_file	*tmp;

	tmp = *file;
	*file = (*file)->next;
	free(tmp);
}

void		ft_del_all_param(t_file **file)
{
	while (*file)
		ft_del_first_param(file);
}

int			ft_add_param(t_file **file, short id)
{
	t_file	*tmp;

	tmp = *file;
	if (*file)
	{
		while (tmp->next)
			tmp = tmp->next;
		if ((tmp->next = (t_file*)ft_memalloc(sizeof(t_file))) == NULL)
			return (0);
		tmp->next->id = id;
		tmp->next->next = NULL;
	}
	else
	{
		if ((*file = (t_file*)ft_memalloc(sizeof(t_file))) == NULL)
			return (0);
		(*file)->id = id;
		(*file)->next = NULL;
	}
	return (1);
}
