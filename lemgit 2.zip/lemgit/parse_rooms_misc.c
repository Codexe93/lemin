/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse_rooms_misc.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 20:19:24 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/14 10:11:54 by mmervoye         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "./libft/libft.h"

int					check_start_end(char **tab)
{
	int			end;
	int			start;

	end = 0;
	start = 0;
	while (*tab)
	{
		if (!ft_strcmp(*tab, "##start"))
			start++;
		else if (!ft_strcmp(*tab, "##end"))
			end++;
		tab += 1;
	}
	if (start != 1 || end != 1)
		return (-1);
	return (0);
}

int					word_count(const char *s, char c)
{
	int		i;
	int		count;

	i = 0;
	count = 0;
	while (s[i])
	{
		if (s[i] != c && (s[i + 1] == c || !s[i + 1]))
			count++;
		i++;
	}
	return (count);
}

static t_room		*clean_rooms_p2(t_info *infos, int count)
{
	int			i;
	int			j;
	t_room		*new;

	if ((new = (t_room *)ft_memalloc(sizeof(t_room) * count)) == NULL)
		return (NULL);
	i = -1;
	j = 0;
	while (++i < infos->nb_room)
	{
		if (infos->room[i].name != NULL)
		{
			if ((new[j].name = ft_strdup(infos->room[i].name)) == NULL)
				return (NULL);
			new[j].id = infos->room[i].id;
			new[j].x = infos->room[i].x;
			new[j].y = infos->room[i].y;
			new[j].attribute = infos->room[i].attribute;
			j++;
		}
	}
	return (new);
}

int					clean_rooms(t_info *infos)
{
	int				i;
	int				count;
	t_room			*new;

	i = -1;
	count = 0;
	while (++i < infos->nb_room)
	{
		if (infos->room[i].name != NULL)
			count++;
	}
	if (count == infos->nb_room)
		return (0);
	new = clean_rooms_p2(infos, count);
	if (!new)
		return (-1);
	i = -1;
	ft_free_data(infos);
	infos->nb_room = count;
	infos->room = new;
	return (0);
}

int					free_and_return_err(char *line, char *line2, char **tab)
{
	error_display(-1, -1);
	if (line)
		ft_strdel(&line);
	else if (line2)
		ft_strdel(&line2);
	if (tab)
		ft_deltab(&tab);
	return (-1);
}
