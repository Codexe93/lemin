/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   parse.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: mmervoye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/06 13:12:00 by mmervoye          #+#    #+#             */
/*   Updated: 2018/12/15 03:46:00 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"
#include "./libft/ft_printf/ft_printf.h"

static void			ft_entry_error(int id)
{
	if (id == 0)
	{
		ft_printf("\x1B[31mERROR\x1B[0m : Empty file or");
		ft_printf(" get_next_line() exception, aborting.\n");
		exit(1);
	}
	if (id == 1)
	{
		ft_printf("\x1B[35mEXCEPTION\x1B[0m : Malloc break exception.\n");
		exit(1);
	}
}

static void			ft_invalid_line_format(char **line, char **log)
{
	ft_printf("\x1B[31mERROR\x1B[0m : Invalid ant line format, aborting.\n");
	ft_strdel(line);
	ft_strdel(log);
	exit(1);
}

static void			ft_check_antline(char **line, char **log)
{
	char			*str;
	int				i;

	str = *line;
	i = 0;
	if (ft_atoi(str) <= 0 || !(ft_strlen(str)))
	{
		ft_printf("\x1B[31mERROR\x1B[0m : No ants, aborting.\n");
		ft_strdel(line);
		ft_strdel(log);
		exit(1);
	}
	while (str[i])
	{
		if ((str[i] == '-' || str[i] == '+') && i != 0)
			ft_invalid_line_format(line, log);
		else if (!(ft_isdigit(str[i])) && str[i] != '-' && str[i] != '+')
			ft_invalid_line_format(line, log);
		i++;
	}
	ft_strdel(line);
}

int					parse(t_info *infos)
{
	char			*line;
	char			*log;

	if (!(log = ft_strnew(0)))
		ft_entry_error(1);
	if ((get_next_line(0, &line)) < 1)
		ft_entry_error(0);
	infos->nb_ants = ft_atoi(line);
	ft_check_antline(&line, &log);
	infos->room = NULL;
	line = parse_rooms(infos, &log);
	if (line == NULL || infos->room[0].name == NULL \
		|| infos->room[1].name == NULL)
	{
		ft_strdel(&log);
		ft_free_data(infos);
		return (-1);
	}
	clean_rooms(infos);
	ft_parse_tubes(line, infos, 0, &log);
	ft_cat_buff(infos, &log);
	if (infos->flag_d == 0)
		ft_printf("%d\n%s\n", infos->nb_ants, log);
	ft_strdel(&log);
	return (0);
}
