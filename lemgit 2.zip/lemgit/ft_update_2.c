/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_update_2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/14 00:52:28 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:21:38 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"

void	ft_mv_next(t_big *big, int curr, int k, int *index)
{
	big->mat[curr][k] = *index;
	big->mat[k][curr] = *index;
	(*index)++;
}

void	ft_mv_tmp(t_big *big, int *line, int *k, t_info info)
{
	big->mat[*line][*k] = 1;
	big->mat[*k][*line] = 1;
	big->tmp_mat[*k][*line] = 1;
	big->tmp_mat[*line][*k] = 1;
	*line = *k;
	*k = info.nb_room;
}
