/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check_links.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 21:41:21 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/14 22:04:31 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"
#include "libft/ft_printf/ft_printf.h"

static void	ft_exception_tube_3(t_info *data, char **log)
{
	ft_free_data(data);
	ft_free_links(data);
	ft_strdel(log);
	ft_printf("\x1B[31mERROR\x1B[0m : End or start room doesn't");
	ft_printf(" have links, aborting.\n");
	exit(1);
}

static int	ft_check_line(t_info *data, int index, char **log)
{
	int		i;

	i = 0;
	while (i < data->nb_room)
	{
		if (data->links[index][i] == 1)
			return (1);
		i++;
	}
	if (data->room[index].attribute != 0)
		ft_exception_tube_3(data, log);
	return (0);
}

int			ft_return_n_free(char **line, char **log, int id, t_info *info)
{
	if (id == 1)
	{
		if (ft_strlen(*line) > BUFFS - 1)
			ft_exception_tube_1(line, info, 1, log);
		if (info->cat + ft_strlen(*line) > BUFFS)
		{
			if (!(*log = ft_strjoinf(*log, info->buffer)))
				ft_exception_tube_1(line, info, 1, log);
			ft_bzero(info->buffer, BUFFS);
			info->cat = 0;
		}
		ft_stradd(&(info->buffer[0]), *line, info->cat);
		info->cat = ft_strlen(info->buffer);
	}
	ft_strdel(line);
	return (0);
}

int			ft_check_links(t_info *data, char **log)
{
	int		i;

	i = 0;
	while (i < data->nb_room)
	{
		if (ft_check_line(data, i, log))
			return (1);
		i++;
	}
	return (0);
}
