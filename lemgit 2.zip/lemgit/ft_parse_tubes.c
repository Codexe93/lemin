/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_parse_tubes.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/05 19:52:00 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 05:42:14 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"
#include "libft/libft.h"

int			ft_is_int_tab(char *line, t_info *data, int *i)
{
	size_t	l1;
	size_t	l2;

	l2 = ft_strclen(line, '-');
	*i = 0;
	while (*i < data->nb_room)
	{
		if (line[0] != data->room[*i].name[0])
		{
			(*i)++;
			continue ;
		}
		l1 = ft_strlen(data->room[*i].name);
		if (l2 >= l1)
			if (!(ft_strncmp(line, data->room[*i].name, l2)))
				return ((int)l2);
		if (l2 < l1)
			if (!(ft_strncmp(line, data->room[*i].name, l1)))
				return ((int)l1);
		(*i)++;
	}
	return (0);
}

void		ft_cat_buff(t_info *info, char **log)
{
	if (info->buffer[0] != '\0')
		if (!(*log = ft_strjoinf(*log, info->buffer)))
		{
			ft_exception_tube_1(NULL, info, 2, log);
			exit(1);
		}
}

static int	ft_add_tube(t_info *info, int *data, char **log, char *cpy)
{
	int		len;

	if (info->links[data[0]][data[1]] == 1)
		return (ft_warning_tube_4());
	info->links[data[0]][data[1]] = 1;
	info->links[data[1]][data[0]] = 1;
	if ((len = ft_strlen(cpy)) > BUFFS - 1)
	{
		ft_exception_tube_1(NULL, info, 2, log);
		exit(1);
	}
	if (info->cat + len > BUFFS)
	{
		if (!(*log = ft_strjoinf(*log, info->buffer)))
		{
			ft_exception_tube_1(NULL, info, 2, log);
			return (1);
		}
		ft_bzero(info->buffer, BUFFS + 4);
		info->cat = 0;
	}
	ft_stradd(&(info->buffer[0]), cpy, info->cat);
	info->cat = ft_strlen(info->buffer);
	return (0);
}

int			ft_valid_tube(char *line, t_info *data, char **log, char *cpy)
{
	int		move;
	char	*addr;
	int		co[2];

	if (line[0] == '#' || line[0] == 'L')
		return (ft_return_n_free(&line, log, 1, data));
	if (ft_strlen(line) == 0 || line[0] == '-')
		return (ft_warning_tube_2(&line));
	if (!(move = ft_is_int_tab(line, data, &co[0])))
		return (ft_warning_tube_1(&line));
	if (*(addr = line + move) != '-')
		return (ft_warning_tube_1(&line));
	addr++;
	if (ft_strlen(addr) == 0)
		return (ft_warning_tube_2(&line));
	if (ft_strchr(addr, '-'))
		return (ft_warning_tube_3(&line));
	if (!(move = ft_is_int_tab(addr, data, &co[1])))
		return (ft_warning_tube_1(&line));
	if (*(addr = addr + move) != '\0')
		return (ft_warning_tube_1(&line));
	return ((ft_add_tube(data, &co[0], log, cpy) > 0) ? ft_quit_free(line)
			: ft_return_n_free(&line, log, 0, data));
}

void		ft_parse_tubes(char *line, t_info *data, int i, char **log)
{
	data->t = data->nb_room;
	if (!(data->links = (short**)ft_memalloc(sizeof(short*) * (data->t + 1))))
		ft_exception_tube_1(&line, data, 0, log);
	data->links[0] = NULL;
	while (i < data->nb_room)
	{
		data->links[i + 1] = NULL;
		if (!(data->links[i] = (short*)ft_memalloc(sizeof(short) * data->t)))
			ft_exception_tube_1(&line, data, 1, log);
		i++;
	}
	i = 1;
	if (ft_valid_tube(line, data, log, line))
		i = 2;
	while (i == 1)
	{
		if ((i = get_next_line(0, &line)) == -1)
			ft_exception_tube_2(data, log);
		ft_check_it(data, i, &line, log);
		if (i == 1)
			if (ft_valid_tube(line, data, log, line))
				i = 2;
	}
	if (i == 2)
		ft_check_it(data, 0, NULL, log);
}
