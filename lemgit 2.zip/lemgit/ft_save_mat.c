/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_save_mat.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/13 15:57:07 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:20:29 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft/libft.h"
#include "lem_in.h"

static int		ft_addtab(t_save **save, short **mat, t_big big, int debit)
{
	t_save		*tmp;
	int			i;
	int			j;

	i = -1;
	tmp = *save;
	while (tmp->next)
		tmp = tmp->next;
	if (!(tmp->next = (t_save*)ft_memalloc(sizeof(t_save))))
		return (0);
	tmp->next->score = big.score;
	tmp->next->next = NULL;
	tmp->next->debit = debit;
	if (!(tmp->next->tab = (short**)malloc(sizeof(short*) * debit)))
		return (0);
	while (++i < debit)
	{
		j = -1;
		if (!(tmp->next->tab[i] = (short*)malloc(sizeof(short) * big.size)))
			return (0);
		while (++j < big.size)
			tmp->next->tab[i][j] = mat[i][j];
	}
	return (1);
}

static int		ft_addinit(t_save **save, short **mat, t_big big, int debit)
{
	int			i;
	int			j;

	i = -1;
	if (!(*save = (t_save*)ft_memalloc(sizeof(t_file))))
		return (0);
	(*save)->score = big.score;
	(*save)->next = NULL;
	(*save)->debit = debit;
	if (!((*save)->tab = (short**)malloc(sizeof(short*) * debit)))
		return (0);
	while (++i < debit)
	{
		j = -1;
		if (!((*save)->tab[i] = (short*)malloc(sizeof(short) * big.size)))
			return (0);
		while (++j < big.size)
			(*save)->tab[i][j] = mat[i][j];
	}
	return (1);
}

int				ft_save_manager(t_save **save, t_big *big, t_info *info)
{
	short		**mat;
	int			i;

	i = -1;
	if (!(mat = ft_convert_mat(info, *big)))
		return (0);
	if (!(ft_calc_score(mat, big, info->nb_ants, info->debit)))
		return (0);
	if (*save)
	{
		if (!(ft_addtab(save, mat, *big, info->debit)))
			return (0);
	}
	else
	{
		if (!(ft_addinit(save, mat, *big, info->debit)))
			return (0);
	}
	while (++i < info->debit)
		free(mat[i]);
	free(mat);
	mat = NULL;
	return (1);
}

short			**ft_choose_mat(t_save *save, t_info *info, t_big big)
{
	int			min;
	t_save		*tmp;

	tmp = save;
	min = -1;
	if (!big.end && !info->debit)
		return (NULL);
	while (tmp)
	{
		if (min == -1 || tmp->score <= min)
			min = tmp->score;
		tmp = tmp->next;
	}
	while (save->score != min)
		save = save->next;
	info->debit = save->debit;
	return (save->tab);
}
