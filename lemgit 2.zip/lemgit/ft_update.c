/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_update.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rmarracc <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2018/12/11 17:49:39 by rmarracc          #+#    #+#             */
/*   Updated: 2018/12/15 04:21:17 by rmarracc         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "lem_in.h"

int			ft_organize_start(t_big *big, t_info info, int k)
{
	int		prev;
	int		curr;
	int		index;

	prev = -1;
	curr = 1;
	index = 3;
	while (curr != 0)
	{
		while (k < info.nb_room)
		{
			if (big->mat[curr][k] > 2 && k != prev && k != curr && k != 1)
			{
				ft_mv_next(big, curr, k, &index);
				prev = curr;
				curr = k;
				k = info.nb_room + 1;
			}
			k++;
			if (k == info.nb_room)
				return (0);
		}
		k = 0;
	}
	return (1);
}

int			ft_organize(t_big *big, t_info info)
{
	int		k;
	int		ret;

	k = 0;
	ret = 1;
	while (k < info.nb_room && ret)
	{
		if (big->mat[1][k] > 2)
			ret = ft_organize_start(big, info, k);
		k++;
	}
	return (ret);
}

int			ft_min_line(t_big *big, t_info info, int *line, int index)
{
	int		k;
	int		min;
	int		kmin;

	kmin = -1;
	min = -1;
	k = -1;
	while (++k < info.nb_room)
	{
		if (big->tmp_mat[*line][k] > 1 && big->mat[*line][k] == 1
				&& big->mark[k] != 0)
			if (big->mark[k] < min || min == -1)
			{
				min = big->mark[k];
				kmin = k;
			}
		if (big->tmp_mat[*line][k] == -1 && big->mat[*line][k] > 2
				&& big->mark[k] != 0)
		{
			ft_mv_tmp(big, line, &k, info);
			kmin = ft_min_line(big, info, line, index + 1);
		}
	}
	big->mod++;
	return (kmin);
}

int			ft_up_step(t_big *big, t_info info, int line, int index)
{
	int		min;

	if (line == 0)
		return (1);
	min = ft_min_line(big, info, &line, index);
	if (min == -1 && big->mod == 0)
		return (0);
	if (min == -1)
		return (1);
	big->mat[line][min] = index;
	big->mat[min][line] = index;
	return (ft_up_step(big, info, min, index + 1));
}

int			ft_update(t_big *big, t_info *info, t_save **save)
{
	int		ret;
	int		k;
	int		j;

	big->mod = 0;
	big->end = 0;
	k = 0;
	ret = ft_up_step(big, *info, 1, 3);
	ft_organize(big, *info);
	while (k < info->nb_room)
	{
		j = 0;
		while (j < info->nb_room)
		{
			big->tmp_mat[k][j] = big->mat[k][j];
			j++;
		}
		k++;
	}
	big->current = 0;
	if ((!ft_save_manager(save, big, info)))
		return (0);
	return (ret);
}
